<?php
    class NilaiMahasiswa {
        var $nim;
        var $matakuliah;
        var $nilai;

        function __construct( $nim, $matakuliah, $nilai) {
            $this->nim = $nim;
            $this->matakuliah = $matakuliah;
            $this->nilai = $nilai;
        }

        function grade() {
            if ($this->nilai > 55 ){
                return 'LULUS';
            }else {
                return 'TIDAK LULUS';
            }
        }

        function hasil() {
            if ($this->nilai < 35 ) return 'E';
            elseif ($this->nilai >= 36 && $this->nilai < 56) return 'D';
            elseif ($this->nilai >= 56 && $this->nilai < 70) return 'C';
            elseif ($this->nilai >= 70 && $this->nilai < 85) return 'B';
            elseif ($this->nilai >= 85 && $this->nilai <= 100) return 'A';
        }
    }
?>